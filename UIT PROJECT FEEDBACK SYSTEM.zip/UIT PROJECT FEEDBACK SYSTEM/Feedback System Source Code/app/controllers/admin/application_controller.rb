class Admin::ApplicationController < ActionController::Base
end
